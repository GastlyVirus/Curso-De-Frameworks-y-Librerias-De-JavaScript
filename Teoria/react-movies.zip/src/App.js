import "./styles.css";
import Form from "./Form";

const movies = [
  {
    name: "Avenger",
    available: 5
  },
  {
    name: "Terminator",
    available: 3
  },
  {
    name: "Nemo",
    available: 4
  },
  {
    name: "Jocker",
    available: 1
  }
];

export default function App() {
  return (
    <div className="App">
      <h1>Peliculas</h1>
      {movies.map((movie) => (
        <Form movie={movie} />
      ))}
    </div>
  );
}
