<template>
  <img alt="Vue logo" src="./assets/logo.png" />
  <h2>Peliculas</h2>
  <Form msg="Hello Vue 3 in CodeSandbox!" />
</template>

<script>
import Form from "./components/Form.vue";
export default {
  name: "App",
  components: {
    Form: Form,
  },
};
</script>

<style lang="scss">
@import "./styles/_variables.scss";

html,
body {
  background: $bg;
  color: $color;
  margin: 0;
}

h2 {
  border-botton: 1px solid $color;
  padding-botton: 10px;
}
</style>
