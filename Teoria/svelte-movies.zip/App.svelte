<script>
import Form from "./Form.svelte";
</script>

<main>
  <h2>Peliculas</h2>
  <Form/>
</main>