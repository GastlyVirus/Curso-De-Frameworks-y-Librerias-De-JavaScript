<script>
  import { form, button } from "./styles.js";

  const movies = [
    {
      name: "Avengers",
      quantity: 0,
      available: 3
    },
    {
      name: "Terminator",
      quantity: 0,
      available: 5
    }
  ];
</script>

 {#each movies as movie}

 <form class="{form}">
  <h3>{movie.name}</h3>
  <button class="{button}" type="button" on:click={() => movie.quantity -= 1} disabled={movie.quantity <= 0}>-</button>
  {movie.quantity}
  <button class="{button}" type="button" on:click={() => movie.quantity += 1} disabled={movie.quantity >= movie.available}>+</button>
  </form>
  {/each}

  <style>
  button {
  }
  button:hover {
  }
  button[disabled] {
  }
</style>